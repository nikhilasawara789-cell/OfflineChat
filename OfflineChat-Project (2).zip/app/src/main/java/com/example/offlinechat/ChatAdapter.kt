package com.example.offlinechat

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.TextView

data class ChatMsg(val sender: String, val text: String, val mine: Boolean, var seen: Boolean = false)

class ChatAdapter(private val ctx: Context, private val items: List<ChatMsg>, private val mineColor: () -> Int) : BaseAdapter() {
    override fun getCount() = items.size
    override fun getItem(position: Int) = items[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val v = convertView ?: LayoutInflater.from(ctx).inflate(R.layout.item_message, parent, false)
        val m = items[position]
        val root = v.findViewById<LinearLayout>(R.id.root)
        val bubble = v.findViewById<LinearLayout>(R.id.bubble)
        val sender = v.findViewById<TextView>(R.id.sender)
        val status = v.findViewById<TextView>(R.id.status)
        v.findViewById<TextView>(R.id.text).text = m.text
        if (m.mine) {
            // Meri message: daayi taraf, hara bubble
            root.gravity = Gravity.END
            bubble.setBackgroundResource(R.drawable.bubble_me)
            (bubble.background.mutate() as GradientDrawable).setColor(mineColor())
            sender.visibility = View.GONE
            status.visibility = View.VISIBLE
            status.text = if (m.seen) "✓✓ seen" else "✓ sent"
            status.setTextColor(if (m.seen) 0xFF1E88E5.toInt() else 0xFF6B7280.toInt())
        } else {
            // Doosre ka message: baayi taraf, grey bubble, naam ke saath
            root.gravity = Gravity.START
            bubble.setBackgroundResource(R.drawable.bubble_other)
            sender.visibility = View.VISIBLE
            status.visibility = View.GONE
            sender.text = m.sender
        }
        return v
    }
}
