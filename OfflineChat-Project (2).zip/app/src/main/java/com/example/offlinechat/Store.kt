package com.example.offlinechat

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

object Store {
    var unlocked = false
    val themes = listOf(
        Triple("Violet", 0xFF6C5CE7.toInt(), 0xFFE0DBFF.toInt()),
        Triple("Ocean", 0xFF1E88E5.toInt(), 0xFFCFE8FF.toInt()),
        Triple("Sunset", 0xFFFF6B6B.toInt(), 0xFFFFD9D2.toInt()),
        Triple("Forest", 0xFF2E8B57.toInt(), 0xFFD4F1DC.toInt())
    )

    private fun sp(c: Context) = c.getSharedPreferences("chatly", Context.MODE_PRIVATE)
    private fun hash(p: String) = MessageDigest.getInstance("SHA-256").digest(("chatly|$p").toByteArray())
        .joinToString("") { "%02x".format(it) }

    fun hasAccount(c: Context) = sp(c).contains("user")
    fun user(c: Context) = sp(c).getString("user", "")!!
    fun name(c: Context) = sp(c).getString("name", "")!!
    fun theme(c: Context) = sp(c).getInt("theme", 0)
    fun setTheme(c: Context, i: Int) = sp(c).edit().putInt("theme", i).apply()
    fun setName(c: Context, n: String) = sp(c).edit().putString("name", n).apply()
    fun check(c: Context, p: String) = sp(c).getString("ph", "") == hash(p)
    fun create(c: Context, u: String, n: String, p: String) =
        sp(c).edit().putString("user", u).putString("name", n).putString("ph", hash(p)).apply()

    fun friends(c: Context): Map<String, String> {
        val o = JSONObject(sp(c).getString("friends", "{}")!!)
        return o.keys().asSequence().associateWith { o.getString(it) }
    }
    fun addFriend(c: Context, u: String, n: String) {
        val o = JSONObject(sp(c).getString("friends", "{}")!!).put(u, n)
        sp(c).edit().putString("friends", o.toString()).apply()
    }

    // Har friend ki chat alag key me, sirf is app ke private storage me
    fun chat(c: Context, u: String): List<ChatMsg> {
        val a = JSONArray(sp(c).getString("chat_$u", "[]")!!)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it); ChatMsg(o.getString("s"), o.getString("t"), o.getBoolean("m"), o.optBoolean("r", false))
        }
    }
    fun markSeen(c: Context, u: String) {
        val a = JSONArray(sp(c).getString("chat_$u", "[]")!!)
        for (i in 0 until a.length()) { val o = a.getJSONObject(i); if (o.getBoolean("m")) o.put("r", true) }
        sp(c).edit().putString("chat_$u", a.toString()).apply()
    }
    fun addMsg(c: Context, u: String, m: ChatMsg) {
        val a = JSONArray(sp(c).getString("chat_$u", "[]")!!)
        a.put(JSONObject().put("s", m.sender).put("t", m.text).put("m", m.mine).put("r", m.seen))
        sp(c).edit().putString("chat_$u", a.toString()).apply()
    }
}
