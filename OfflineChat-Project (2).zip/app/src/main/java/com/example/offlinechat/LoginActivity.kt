package com.example.offlinechat

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        val user = findViewById<EditText>(R.id.user)
        val name = findViewById<EditText>(R.id.name)
        val pass = findViewById<EditText>(R.id.pass)
        val has = Store.hasAccount(this)
        val title = findViewById<TextView>(R.id.title)
        if (has) {
            user.visibility = View.GONE; name.visibility = View.GONE
            title.text = "Welcome back, ${Store.name(this)}"
        } else title.text = "Account banao"

        findViewById<Button>(R.id.login).apply {
            text = if (has) "Login" else "Create account"
            setOnClickListener {
                val p = pass.text.toString()
                if (has) {
                    if (Store.check(this@LoginActivity, p)) go() else pass.error = "Galat password"
                } else {
                    val u = user.text.toString().trim().lowercase()
                    val n = name.text.toString().trim().replace("|", " ")
                    if (!Regex("[a-z0-9_]{3,15}").matches(u)) { user.error = "3-15 akshar: a-z, 0-9, _"; return@setOnClickListener }
                    if (n.isEmpty()) { name.error = "Naam likho"; return@setOnClickListener }
                    if (p.length < 6) { pass.error = "Kam se kam 6 akshar"; return@setOnClickListener }
                    Store.create(this@LoginActivity, u, n, p)
                    go()
                }
            }
        }
    }

    private fun go() {
        Store.unlocked = true
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
