Lumora - offline nearby chat app.
Build: upload this zip to your GitHub repository; the workflow builds app-debug.apk (see Actions > Artifacts).
