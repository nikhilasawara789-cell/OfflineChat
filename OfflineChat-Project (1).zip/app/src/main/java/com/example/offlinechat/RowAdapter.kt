package com.example.offlinechat

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

data class Row(val key: String, val title: String, val sub: String, val online: Boolean, val unread: Int, val locked: Boolean)

class RowAdapter(private val ctx: Context, private val items: List<Row>, private val primary: () -> Int) : BaseAdapter() {
    override fun getCount(): Int = items.size
    override fun getItem(position: Int): Row = items[position]
    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val fresh = convertView == null
        val v = convertView ?: LayoutInflater.from(ctx).inflate(R.layout.item_row, parent, false)
        val r = items[position]
        Themes.avatar(v.findViewById<TextView>(R.id.avatar), r.title, r.key)
        v.findViewById<TextView>(R.id.rowTitle).text = r.title
        v.findViewById<TextView>(R.id.rowSub).text = r.sub
        v.findViewById<View>(R.id.dot).visibility = if (r.online) View.VISIBLE else View.GONE
        v.findViewById<View>(R.id.lockIcon).visibility = if (r.locked) View.VISIBLE else View.GONE
        val b = v.findViewById<TextView>(R.id.badge)
        b.visibility = if (r.unread > 0) View.VISIBLE else View.GONE
        b.text = r.unread.toString()
        (b.background.mutate() as GradientDrawable).setColor(primary())
        if (fresh) {
            v.alpha = 0f
            v.translationY = 30f
            v.animate().alpha(1f).translationY(0f).setStartDelay(position * 35L).setDuration(260).start()
        }
        return v
    }
}
