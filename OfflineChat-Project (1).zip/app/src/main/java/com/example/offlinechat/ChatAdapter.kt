package com.example.offlinechat

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.TextView

data class ChatMsg(val sender: String, val text: String, val mine: Boolean, var seen: Boolean = false)

class ChatAdapter(private val ctx: Context, private val items: List<ChatMsg>, private val theme: () -> Theme) : BaseAdapter() {
    var animatedUpTo = 0
    override fun getCount(): Int = items.size
    override fun getItem(position: Int): ChatMsg = items[position]
    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val v = convertView ?: LayoutInflater.from(ctx).inflate(R.layout.item_message, parent, false)
        val t = theme()
        val m = items[position]
        val root = v.findViewById<LinearLayout>(R.id.root)
        val bubble = v.findViewById<LinearLayout>(R.id.bubble)
        val sender = v.findViewById<TextView>(R.id.sender)
        val status = v.findViewById<TextView>(R.id.status)
        val text = v.findViewById<TextView>(R.id.text)
        text.text = m.text
        text.setTextColor(if (t.dark) Color.WHITE else Color.parseColor("#111111"))
        bubble.setBackgroundResource(if (m.mine) R.drawable.bubble_me else R.drawable.bubble_other)
        (bubble.background.mutate() as GradientDrawable).setColor(if (m.mine) t.mine else t.other)
        sender.setTextColor(t.primary)
        if (m.mine) {
            root.gravity = Gravity.END
            sender.visibility = View.GONE
            status.visibility = View.VISIBLE
            status.text = if (m.seen) "✓✓ Seen" else "✓ Sent"
            status.setTextColor(if (m.seen) Color.parseColor("#29B6F6") else Color.parseColor("#8A8A99"))
        } else {
            root.gravity = Gravity.START
            sender.visibility = View.VISIBLE
            sender.text = m.sender
            status.visibility = View.GONE
        }
        v.alpha = 1f
        v.translationY = 0f
        if (position >= animatedUpTo) {   // only brand-new messages pop in
            animatedUpTo = position + 1
            v.alpha = 0f
            v.translationY = 40f
            v.animate().alpha(1f).translationY(0f).setDuration(220).start()
        }
        return v
    }
}
