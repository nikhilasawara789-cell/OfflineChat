package com.example.offlinechat

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.widget.TextView

class Theme(val name: String, val primary: Int, val mine: Int, val other: Int, val bg: Int, val sym: String?, val dark: Boolean)

object Themes {
    private fun c(v: Long): Int = v.toInt()

    val all: List<Theme> = listOf(
        Theme("Violet", c(0xFF6C5CE7), c(0xFFE0DBFF), c(0xFFEFEFF4), c(0xFFFFFFFF), null, false),
        Theme("Ocean", c(0xFF1E88E5), c(0xFFCFE8FF), c(0xFFEFF3F8), c(0xFFF5FAFF), null, false),
        Theme("Sunset", c(0xFFFF6B6B), c(0xFFFFD9D2), c(0xFFF6EDEB), c(0xFFFFFAF8), null, false),
        Theme("Forest", c(0xFF2E8B57), c(0xFFD4F1DC), c(0xFFEAF2EC), c(0xFFF7FCF8), null, false),
        Theme("Love ♥", c(0xFFE91E63), c(0xFFFFC1D6), c(0xFFFFF0F5), c(0xFFFFF5F8), "♥", false),
        Theme("Bubbles ○", c(0xFF29B6F6), c(0xFFB3E5FC), c(0xFFE8F6FD), c(0xFFF0FAFF), "○", false),
        Theme("Midnight ✦", c(0xFF5B5BD6), c(0xFF4B4B9A), c(0xFF2A2A3A), c(0xFF14141F), "✦", true),
        Theme("Candy ★", c(0xFFAB47BC), c(0xFFF3C6FF), c(0xFFFBEFFF), c(0xFFFFF7FF), "★", false),
        Theme("Sakura ✿", c(0xFFEC7FA9), c(0xFFFFD6E6), c(0xFFFFF1F6), c(0xFFFFF8FA), "✿", false)
    )

    private val palette = intArrayOf(
        c(0xFF6C5CE7), c(0xFFE91E63), c(0xFF1E88E5), c(0xFF2E8B57),
        c(0xFFFF7043), c(0xFFAB47BC), c(0xFF00ACC1), c(0xFFFFB300)
    )

    fun shade(col: Int, f: Float): Int =
        Color.rgb((Color.red(col) * f).toInt(), (Color.green(col) * f).toInt(), (Color.blue(col) * f).toInt())

    fun gradient(col: Int, r: Float): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(col, shade(col, 0.72f)))
        g.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        return g
    }

    // Round avatar with initials and a colour picked from the username
    fun avatar(tv: TextView, name: String, seed: String) {
        val h = seed.hashCode() and 0x7fffffff
        val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(palette[h % palette.size], palette[(h / 8) % palette.size]))
        g.shape = GradientDrawable.OVAL
        tv.background = g
        tv.text = name.trim().split(" ").filter { it.isNotEmpty() }.take(2).joinToString("") { it.take(1).uppercase() }
    }
}

// Chat wallpaper: theme colour with a soft repeating symbol pattern (hearts, bubbles, stars...)
class Pattern(private val t: Theme) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun draw(canvas: Canvas) {
        canvas.drawColor(t.bg)
        val s = t.sym ?: return
        p.color = t.primary
        p.alpha = 40
        p.textSize = 34f
        var y = 60f
        var row = 0
        while (y < bounds.height() + 60) {
            var x = if (row % 2 == 0) 30f else 85f
            while (x < bounds.width()) { canvas.drawText(s, x, y, p); x += 110f }
            y += 90f
            row++
        }
    }
    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
