package com.example.offlinechat

import android.Manifest
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*

class MainActivity : AppCompatActivity() {
    private val svc = "oc.friends.v1"
    private lateinit var me: String
    private lateinit var myName: String
    private lateinit var client: ConnectionsClient
    private val nearby = mutableMapOf<String, Pair<String, String>>()  // endpointId -> (user, name)
    private val info = mutableMapOf<String, Pair<String, String>>()    // connected endpointId -> (user, name)
    private val live = mutableMapOf<String, String>()                  // user -> endpointId
    private val asked = mutableSetOf<String>()
    private val incoming = linkedMapOf<String, String>()
    private val unread = mutableMapOf<String, Int>()
    private val rowsData = mutableListOf<Row>()
    private val chatItems = mutableListOf<ChatMsg>()
    private var tab = 0
    private var current: String? = null
    private var typing = false
    private var lastTyping = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val stopTyping = Runnable { typing = false; updateTitle() }
    private lateinit var rowAdapter: RowAdapter
    private lateinit var chatAdapter: ChatAdapter
    private val advert: String get() = "$me|$myName"
    private val th: Theme get() = Themes.all[Store.theme(this)]
    private val screenW: Float get() = resources.displayMetrics.widthPixels.toFloat()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Store.unlocked) { startActivity(Intent(this, LoginActivity::class.java)); finish(); return }
        me = Store.user(this); myName = Store.name(this)
        setContentView(R.layout.activity_main)
        client = Nearby.getConnectionsClient(this)
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("chat", "Messages", NotificationManager.IMPORTANCE_HIGH))

        rowAdapter = RowAdapter(this, rowsData) { th.primary }
        findViewById<ListView>(R.id.list).apply {
            adapter = rowAdapter
            setOnItemClickListener { _, _, i, _ -> onRow(rowsData[i].key) }
            setOnItemLongClickListener { _, _, i, _ -> if (tab == 0) { chatMenu(rowsData[i].key); true } else false }
        }
        chatAdapter = ChatAdapter(this, chatItems) { th }
        findViewById<ListView>(R.id.chatList).adapter = chatAdapter
        listOf(R.id.tab0, R.id.tab1, R.id.tab2).forEachIndexed { i, id ->
            findViewById<TextView>(id).setOnClickListener { tab = i; refresh() }
        }
        findViewById<View>(R.id.indicator).layoutParams.width = (screenW / 3).toInt()
        Themes.avatar(findViewById<TextView>(R.id.avatarMe), myName, me)
        findViewById<TextView>(R.id.hello).text = "Hello, $myName 👋"
        findViewById<View>(R.id.settings).setOnClickListener { settings() }
        findViewById<View>(R.id.back).setOnClickListener { closeChat() }
        findViewById<View>(R.id.themeBtn).setOnClickListener { themePicker() }
        findViewById<View>(R.id.moreBtn).setOnClickListener { current?.let { chatMenu(it) } }

        val input = findViewById<EditText>(R.id.input)
        input.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val ep = current?.let { live[it] } ?: return
                val now = System.currentTimeMillis()
                if (!s.isNullOrEmpty() && now - lastTyping > 2000) { lastTyping = now; send(ep, "T") }
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        findViewById<View>(R.id.send).setOnClickListener { btn ->
            pop(btn)
            val u = current ?: return@setOnClickListener
            val t = input.text.toString().trim()
            if (t.isEmpty()) return@setOnClickListener
            val ep = live[u]
            if (ep == null) { toast("Your friend is out of range"); return@setOnClickListener }
            send(ep, "M|$t")
            val m = ChatMsg(myName, t, true)
            Store.addMsg(this, u, m); chatItems += m; chatAdapter.notifyDataSetChanged()
            input.text.clear()
        }
        applyTheme(); refresh()
        if (hasPermissions()) startNearby()
        else ActivityCompat.requestPermissions(this, requiredPermissions() + notifPerm(), 1)
    }

    // ---------- permissions & Nearby ----------
    private fun notifPerm(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.POST_NOTIFICATIONS) else emptyArray()

    private fun requiredPermissions(): Array<String> {
        val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 31) {
            p += Manifest.permission.BLUETOOTH_ADVERTISE
            p += Manifest.permission.BLUETOOTH_CONNECT
            p += Manifest.permission.BLUETOOTH_SCAN
        }
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.NEARBY_WIFI_DEVICES
        return p.toTypedArray()
    }

    private fun hasPermissions(): Boolean = requiredPermissions().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (hasPermissions()) startNearby()
    }

    private fun startNearby() {
        client.startAdvertising(advert, svc, connCb, AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build())
        startDisc()
    }

    private fun startDisc() {
        client.startDiscovery(svc, discCb, DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build())
    }

    private fun parse(n: String): Pair<String, String> = n.substringBefore("|") to n.substringAfter("|", n.substringBefore("|"))

    private fun send(ep: String, s: String) {
        client.sendPayload(ep, Payload.fromBytes(s.toByteArray()))
    }

    private val discCb: EndpointDiscoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, i: DiscoveredEndpointInfo) {
            val p = parse(i.endpointName)
            if (p.first == me) return
            nearby[id] = p
            if (Store.friends(this@MainActivity).containsKey(p.first) && me > p.first && !live.containsKey(p.first))
                client.requestConnection(advert, id, connCb)
            refresh()
        }
        override fun onEndpointLost(id: String) { nearby.remove(id); refresh() }
    }

    private val connCb: ConnectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, i: ConnectionInfo) {
            info[id] = parse(i.endpointName)
            client.acceptConnection(id, payCb)
        }
        override fun onConnectionResult(id: String, r: ConnectionResolution) {
            if (!r.status.isSuccess) return
            val u = info[id]?.first ?: return
            live[u] = id
            if (id in asked) send(id, "FR|$me|$myName")
            refresh()
        }
        override fun onDisconnected(id: String) {
            live.values.remove(id); nearby.clear()
            client.stopDiscovery(); startDisc()
            refresh()
        }
    }

    private val payCb: PayloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, p: Payload) {
            val raw = String(p.asBytes() ?: return)
            val u = info[id]?.first ?: return
            val rest = raw.substringAfter("|", "")
            val fr = Store.friends(this@MainActivity)
            when (raw.substringBefore("|")) {
                "FR" -> {
                    val n = rest.substringAfter("|", u)
                    if (u in fr) send(id, "FA|$me|$myName") else { incoming[u] = n; push("New friend request", "$n (@$u)") }
                    refresh()
                }
                "T" -> if (u in fr && u == current) {
                    typing = true; updateTitle()
                    handler.removeCallbacks(stopTyping); handler.postDelayed(stopTyping, 3000)
                }
                "S" -> if (u in fr) {
                    Store.markSeen(this@MainActivity, u)
                    if (current == u) { chatItems.forEach { if (it.mine) it.seen = true }; chatAdapter.notifyDataSetChanged() }
                }
                "FA" -> if (id in asked) {
                    asked -= id
                    Store.addFriend(this@MainActivity, u, rest.substringAfter("|", u)); refresh()
                }
                "M" -> if (u in fr) {   // only friends can message you
                    val m = ChatMsg(fr[u] ?: u, rest, false)
                    Store.addMsg(this@MainActivity, u, m)
                    if (current == u) {
                        chatItems += m; chatAdapter.notifyDataSetChanged(); send(id, "S"); typing = false; updateTitle()
                    } else {
                        unread[u] = (unread[u] ?: 0) + 1
                        val priv = Store.isLocked(this@MainActivity, u) || Store.isHidden(this@MainActivity, u)
                        push(if (priv) "New message" else (fr[u] ?: u), if (priv) "Open Lumora to read it" else rest)
                        refresh()
                    }
                }
            }
        }
        override fun onPayloadTransferUpdate(id: String, u: PayloadTransferUpdate) {}
    }

    // ---------- lists ----------
    private fun refresh() {
        runOnUiThread {
            val fr = Store.friends(this)
            rowsData.clear()
            when (tab) {
                0 -> for ((u, n) in fr) {
                    if (Store.isHidden(this, u)) continue
                    val lk = Store.isLocked(this, u)
                    val last = if (lk) "Locked chat" else (Store.chat(this, u).lastOrNull()?.let { (if (it.mine) "You: " else "") + it.text } ?: "Tap to start chatting")
                    rowsData.add(Row(u, n, last, live.containsKey(u), unread[u] ?: 0, lk))
                }
                1 -> for ((id, p) in nearby) {
                    if (p.first in fr) continue
                    rowsData.add(Row(id, p.second, "@${p.first} · Tap to add as a friend", false, 0, false))
                }
                else -> for ((u, n) in incoming) rowsData.add(Row(u, n, "@$u · wants to be your friend", false, 0, false))
            }
            val empty = findViewById<TextView>(R.id.empty)
            empty.text = listOf("No friends yet.\nOpen the Nearby tab to find people.", "No one nearby right now.\nAsk your friend to open Lumora.", "No requests.")[tab]
            empty.visibility = if (rowsData.isEmpty()) View.VISIBLE else View.GONE
            rowAdapter.notifyDataSetChanged()
            findViewById<TextView>(R.id.sub).text = "@$me  ·  ${nearby.size} nearby"
            updateTabs(); updateTitle()
        }
    }

    private fun updateTabs() {
        listOf(R.id.tab0, R.id.tab1, R.id.tab2).forEachIndexed { i, id ->
            findViewById<TextView>(id).setTextColor(if (i == tab) th.primary else Color.parseColor("#8A8A99"))
        }
        findViewById<TextView>(R.id.tab2).text = if (incoming.isEmpty()) "Requests" else "Requests (${incoming.size})"
        findViewById<View>(R.id.indicator).animate().translationX(tab * screenW / 3).setDuration(220).start()
    }

    private fun onRow(k: String) {
        when (tab) {
            0 -> if (Store.isLocked(this, k)) withPin { openChat(k) } else openChat(k)
            1 -> {
                val p = nearby[k] ?: return
                AlertDialog.Builder(this).setTitle("Add friend")
                    .setMessage("Send a friend request to ${p.second} (@${p.first})?")
                    .setPositiveButton("Send") { _, _ ->
                        asked += k
                        if (live[p.first] == k) send(k, "FR|$me|$myName") else client.requestConnection(advert, k, connCb)
                        toast("Request sent")
                    }.setNegativeButton("Cancel", null).show()
            }
            else -> {
                val n = incoming[k] ?: return
                AlertDialog.Builder(this).setTitle("@$k").setMessage("$n wants to be your friend")
                    .setPositiveButton("Accept") { _, _ ->
                        Store.addFriend(this, k, n); live[k]?.let { send(it, "FA|$me|$myName") }
                        incoming.remove(k); refresh()
                    }.setNegativeButton("Decline") { _, _ -> incoming.remove(k); refresh() }.show()
            }
        }
    }

    // ---------- chat screen ----------
    private fun openChat(u: String) {
        current = u; unread.remove(u); typing = false
        chatItems.clear(); chatItems += Store.chat(this, u)
        chatAdapter.animatedUpTo = chatItems.size
        chatAdapter.notifyDataSetChanged()
        Themes.avatar(findViewById<TextView>(R.id.chatAvatar), Store.friends(this)[u] ?: u, u)
        if (Store.isLocked(this, u) || Store.isHidden(this, u)) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        updateTitle()
        live[u]?.let { send(it, "S") }
        val p = findViewById<View>(R.id.chatPanel)
        p.animate().cancel()
        p.translationX = screenW
        p.visibility = View.VISIBLE
        p.animate().translationX(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun closeChat() {
        current = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        val p = findViewById<View>(R.id.chatPanel)
        p.animate().cancel()
        p.animate().translationX(screenW).setDuration(220).withEndAction { p.visibility = View.GONE }.start()
        refresh()
    }

    private fun updateTitle() {
        val u = current ?: return
        findViewById<TextView>(R.id.chatTitle).text = Store.friends(this)[u] ?: u
        findViewById<TextView>(R.id.chatSub).text = if (typing) "typing…" else if (live.containsKey(u)) "Online" else "Out of range"
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (current != null) closeChat() else super.onBackPressed() }

    // Locked / hidden chats close automatically when you leave the app
    override fun onStop() {
        super.onStop()
        val u = current
        if (u != null && (Store.isLocked(this, u) || Store.isHidden(this, u))) closeChat()
    }

    // ---------- themes ----------
    private fun applyTheme() {
        val t = th
        findViewById<View>(R.id.header).background = Themes.gradient(t.primary, 56f)
        findViewById<View>(R.id.chatHead).background = Themes.gradient(t.primary, 0f)
        findViewById<View>(R.id.indicator).setBackgroundColor(t.primary)
        val circle = GradientDrawable()
        circle.shape = GradientDrawable.OVAL
        circle.setColor(t.primary)
        findViewById<View>(R.id.send).background = circle
        findViewById<View>(R.id.inputBar).setBackgroundColor(t.bg)
        val input = findViewById<EditText>(R.id.input)
        val box = GradientDrawable()
        box.cornerRadius = 60f
        box.setColor(Color.parseColor(if (t.dark) "#2A2A3A" else "#F0F0F5"))
        input.background = box
        input.setTextColor(if (t.dark) Color.WHITE else Color.BLACK)
        input.setHintTextColor(Color.parseColor("#8A8A99"))
        findViewById<ListView>(R.id.chatList).apply { background = Pattern(t); cacheColorHint = Color.TRANSPARENT }
        chatAdapter.notifyDataSetChanged(); rowAdapter.notifyDataSetChanged(); updateTabs()
    }

    private fun themePicker() {
        val cur = Store.theme(this)
        val names = Themes.all.mapIndexed { i, t -> (if (i == cur) "✓  " else "     ") + t.name }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Choose a theme")
            .setItems(names) { _, i -> Store.setTheme(this, i); applyTheme() }.show()
    }

    // ---------- chat lock / hide / PIN ----------
    private fun toast(s: String) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }

    private fun pop(v: View) {
        v.animate().scaleX(0.8f).scaleY(0.8f).setDuration(70)
            .withEndAction { v.animate().scaleX(1f).scaleY(1f).setDuration(110).start() }.start()
    }

    private fun pinDialog(title: String, ok: (String) -> Unit) {
        val e = EditText(this)
        e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        e.hint = "PIN"
        AlertDialog.Builder(this).setTitle(title).setView(e)
            .setPositiveButton("OK") { _, _ -> ok(e.text.toString()) }
            .setNegativeButton("Cancel", null).show()
    }

    // Asks for the PIN (or creates one the first time), then runs `then`
    private fun withPin(then: () -> Unit) {
        if (!Store.hasPin(this)) {
            pinDialog("Create a 4–6 digit PIN") { p ->
                if (p.length in 4..6) { Store.setPin(this, p); then() } else toast("PIN must be 4–6 digits")
            }
        } else {
            pinDialog("Enter your PIN") { p ->
                if (Store.checkPin(this, p)) then() else toast("Wrong PIN")
            }
        }
    }

    private fun chatMenu(u: String) {
        val lk = Store.isLocked(this, u)
        val hd = Store.isHidden(this, u)
        val items = arrayOf(if (lk) "Unlock chat" else "Lock chat", if (hd) "Unhide chat" else "Hide chat")
        AlertDialog.Builder(this).setItems(items) { _, w ->
            withPin {
                if (w == 0) {
                    toast(if (Store.toggle(this, "locked", u)) "Chat locked 🔒" else "Chat unlocked")
                } else {
                    val h = Store.toggle(this, "hidden", u)
                    toast(if (h) "Chat hidden. Find it in Settings > Hidden chats" else "Chat unhidden")
                    if (h && current == u) closeChat()
                }
                refresh()
            }
        }.show()
    }

    private fun hiddenChats() {
        withPin {
            val fr = Store.friends(this)
            val hs = Store.hiddenList(this).filter { it in fr }
            if (hs.isEmpty()) {
                toast("No hidden chats")
            } else {
                AlertDialog.Builder(this).setTitle("Hidden chats")
                    .setItems(hs.map { fr[it] ?: it }.toTypedArray()) { _, i -> openChat(hs[i]) }.show()
            }
        }
    }

    private fun settings() {
        AlertDialog.Builder(this).setItems(arrayOf("Change theme", "Hidden chats", "Change PIN", "Edit name", "Log out")) { _, w ->
            when (w) {
                0 -> themePicker()
                1 -> hiddenChats()
                2 -> withPin {
                    pinDialog("Set a new PIN (4–6 digits)") { n ->
                        if (n.length in 4..6) { Store.setPin(this, n); toast("PIN updated") } else toast("PIN must be 4–6 digits")
                    }
                }
                3 -> {
                    val e = EditText(this); e.setText(myName)
                    AlertDialog.Builder(this).setTitle("Edit name").setView(e).setPositiveButton("Save") { _, _ ->
                        val n = e.text.toString().trim().replace("|", " ")
                        if (n.isNotEmpty()) { Store.setName(this, n); toast("Your new name will appear after you log in again") }
                    }.show()
                }
                else -> { Store.unlocked = false; finish(); startActivity(Intent(this, LoginActivity::class.java)) }
            }
        }.show()
    }

    // ---------- notifications ----------
    private fun push(title: String, text: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, "chat").setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(title).setContentText(text).setAutoCancel(true).setContentIntent(pi).build()
        NotificationManagerCompat.from(this).notify(System.nanoTime().toInt(), n)
    }

    override fun onDestroy() {
        if (::client.isInitialized) { client.stopAllEndpoints(); client.stopAdvertising(); client.stopDiscovery() }
        super.onDestroy()
    }
}
