package com.example.offlinechat

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

object Store {
    var unlocked = false

    private fun sp(c: Context) = c.getSharedPreferences("chatly", Context.MODE_PRIVATE)
    private fun hash(p: String) = MessageDigest.getInstance("SHA-256").digest(("chatly|$p").toByteArray())
        .joinToString("") { "%02x".format(it) }

    // PIN, chat lock and hidden chats
    fun hasPin(c: Context): Boolean = sp(c).contains("pin")
    fun setPin(c: Context, p: String) = sp(c).edit().putString("pin", hash("pin|$p")).apply()
    fun checkPin(c: Context, p: String): Boolean = sp(c).getString("pin", "") == hash("pin|$p")
    private fun ids(c: Context, key: String): Set<String> = sp(c).getStringSet(key, emptySet())!!.toSet()
    fun isLocked(c: Context, u: String): Boolean = u in ids(c, "locked")
    fun isHidden(c: Context, u: String): Boolean = u in ids(c, "hidden")
    fun hiddenList(c: Context): Set<String> = ids(c, "hidden")
    // Flips membership of u in the "locked"/"hidden" set and returns the new state
    fun toggle(c: Context, key: String, u: String): Boolean {
        val s = ids(c, key).toMutableSet()
        val on = if (u in s) { s -= u; false } else { s += u; true }
        sp(c).edit().putStringSet(key, s).apply()
        return on
    }

    fun hasAccount(c: Context) = sp(c).contains("user")
    fun user(c: Context) = sp(c).getString("user", "")!!
    fun name(c: Context) = sp(c).getString("name", "")!!
    fun theme(c: Context) = sp(c).getInt("theme", 0)
    fun setTheme(c: Context, i: Int) = sp(c).edit().putInt("theme", i).apply()
    fun setName(c: Context, n: String) = sp(c).edit().putString("name", n).apply()
    fun check(c: Context, p: String) = sp(c).getString("ph", "") == hash(p)
    fun create(c: Context, u: String, n: String, p: String) =
        sp(c).edit().putString("user", u).putString("name", n).putString("ph", hash(p)).apply()

    fun friends(c: Context): Map<String, String> {
        val o = JSONObject(sp(c).getString("friends", "{}")!!)
        return o.keys().asSequence().associateWith { o.getString(it) }
    }
    fun addFriend(c: Context, u: String, n: String) {
        val o = JSONObject(sp(c).getString("friends", "{}")!!).put(u, n)
        sp(c).edit().putString("friends", o.toString()).apply()
    }

    // Har friend ki chat alag key me, sirf is app ke private storage me
    fun chat(c: Context, u: String): List<ChatMsg> {
        val a = JSONArray(sp(c).getString("chat_$u", "[]")!!)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it); ChatMsg(o.getString("s"), o.getString("t"), o.getBoolean("m"), o.optBoolean("r", false))
        }
    }
    fun markSeen(c: Context, u: String) {
        val a = JSONArray(sp(c).getString("chat_$u", "[]")!!)
        for (i in 0 until a.length()) { val o = a.getJSONObject(i); if (o.getBoolean("m")) o.put("r", true) }
        sp(c).edit().putString("chat_$u", a.toString()).apply()
    }
    fun addMsg(c: Context, u: String, m: ChatMsg) {
        val a = JSONArray(sp(c).getString("chat_$u", "[]")!!)
        a.put(JSONObject().put("s", m.sender).put("t", m.text).put("m", m.mine).put("r", m.seen))
        sp(c).edit().putString("chat_$u", a.toString()).apply()
    }
}
