package com.example.offlinechat

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        val user = findViewById<EditText>(R.id.user)
        val name = findViewById<EditText>(R.id.name)
        val pass = findViewById<EditText>(R.id.pass)
        val title = findViewById<TextView>(R.id.title)
        val has = Store.hasAccount(this)

        val logo = findViewById<View>(R.id.logo)
        logo.scaleX = 0.5f; logo.scaleY = 0.5f; logo.alpha = 0f
        logo.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(600).setInterpolator(OvershootInterpolator()).start()
        val form = findViewById<View>(R.id.form)
        form.alpha = 0f; form.translationY = 60f
        form.animate().alpha(1f).translationY(0f).setStartDelay(250).setDuration(500).start()

        if (has) {
            user.visibility = View.GONE
            name.visibility = View.GONE
            title.text = "Welcome back, ${Store.name(this)}"
        } else {
            title.text = "Create your account"
        }

        val btn = findViewById<Button>(R.id.login)
        btn.text = if (has) "Log in" else "Create account"
        btn.setOnClickListener {
            val p = pass.text.toString()
            if (has) {
                if (Store.check(this, p)) go() else pass.error = "Wrong password"
            } else {
                val u = user.text.toString().trim().lowercase()
                val n = name.text.toString().trim().replace("|", " ")
                if (!Regex("[a-z0-9_]{3,15}").matches(u)) { user.error = "3–15 characters: a–z, 0–9, _"; return@setOnClickListener }
                if (n.isEmpty()) { name.error = "Enter your name"; return@setOnClickListener }
                if (p.length < 6) { pass.error = "At least 6 characters"; return@setOnClickListener }
                Store.create(this, u, n, p)
                go()
            }
        }
    }

    private fun go() {
        Store.unlocked = true
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
