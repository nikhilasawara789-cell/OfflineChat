package com.example.offlinechat

import android.Manifest
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*

class MainActivity : AppCompatActivity() {
    private val svc = "oc.friends.v1"
    private lateinit var me: String
    private lateinit var myName: String
    private lateinit var client: ConnectionsClient
    private val nearby = mutableMapOf<String, Pair<String, String>>()  // endpointId -> (user, name)
    private val info = mutableMapOf<String, Pair<String, String>>()    // connected endpointId -> (user, name)
    private val live = mutableMapOf<String, String>()                  // user -> endpointId
    private val asked = mutableSetOf<String>()                         // endpoints jinko request bheji
    private val incoming = linkedMapOf<String, String>()               // user -> name (pending requests)
    private val unread = mutableMapOf<String, Int>()
    private val rows = mutableListOf<String>()
    private val keys = mutableListOf<String>()
    private val chatItems = mutableListOf<ChatMsg>()
    private var tab = 0
    private var current: String? = null
    private var typing = false
    private var lastTyping = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val stopTyping = Runnable { typing = false; updateTitle() }
    private lateinit var listAdapter: ArrayAdapter<String>
    private lateinit var chatAdapter: ChatAdapter
    private val advert: String get() = "$me|$myName"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Store.unlocked) { startActivity(Intent(this, LoginActivity::class.java)); finish(); return }
        me = Store.user(this); myName = Store.name(this)
        setContentView(R.layout.activity_main)
        client = Nearby.getConnectionsClient(this)
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("chat", "Chat", NotificationManager.IMPORTANCE_HIGH))

        listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, rows)
        findViewById<ListView>(R.id.list).apply {
            adapter = listAdapter
            setOnItemClickListener { _, _, i, _ -> onRow(keys[i]) }
        }
        chatAdapter = ChatAdapter(this, chatItems) { Store.themes[Store.theme(this)].third }
        findViewById<ListView>(R.id.chatList).adapter = chatAdapter
        listOf(R.id.tab0, R.id.tab1, R.id.tab2).forEachIndexed { i, id ->
            findViewById<Button>(id).setOnClickListener { tab = i; refresh() }
        }
        findViewById<TextView>(R.id.hello).text = "Hello, $myName 👋"
        findViewById<View>(R.id.settings).setOnClickListener { settings() }
        findViewById<View>(R.id.back).setOnClickListener { closeChat() }

        val input = findViewById<EditText>(R.id.input)
        input.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val ep = current?.let { live[it] } ?: return
                val now = System.currentTimeMillis()
                if (!s.isNullOrEmpty() && now - lastTyping > 2000) { lastTyping = now; send(ep, "T") }
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        findViewById<Button>(R.id.send).setOnClickListener {
            val u = current ?: return@setOnClickListener
            val t = input.text.toString().trim()
            if (t.isEmpty()) return@setOnClickListener
            val ep = live[u]
            if (ep == null) { Toast.makeText(this, "Friend abhi range me nahi hai", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            send(ep, "M|$t")
            val m = ChatMsg(myName, t, true)
            Store.addMsg(this, u, m); chatItems += m; chatAdapter.notifyDataSetChanged()
            input.text.clear()
        }
        applyTheme(); refresh()
        if (hasPermissions()) startNearby()
        else ActivityCompat.requestPermissions(this, requiredPermissions() + notifPerm(), 1)
    }

    private fun notifPerm(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.POST_NOTIFICATIONS) else emptyArray()

    private fun requiredPermissions(): Array<String> {
        val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 31) {
            p += Manifest.permission.BLUETOOTH_ADVERTISE
            p += Manifest.permission.BLUETOOTH_CONNECT
            p += Manifest.permission.BLUETOOTH_SCAN
        }
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.NEARBY_WIFI_DEVICES
        return p.toTypedArray()
    }

    private fun hasPermissions() = requiredPermissions().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (hasPermissions()) startNearby()
    }

    private fun startNearby() {
        client.startAdvertising(advert, svc, connCb, AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build())
        startDisc()
    }

    private fun startDisc() {
        client.startDiscovery(svc, discCb, DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build())
    }

    private fun parse(n: String): Pair<String, String> = n.substringBefore("|") to n.substringAfter("|", n.substringBefore("|"))
    private fun send(ep: String, s: String) {
        client.sendPayload(ep, Payload.fromBytes(s.toByteArray()))
    }

    private val discCb: EndpointDiscoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, i: DiscoveredEndpointInfo) {
            val p = parse(i.endpointName)
            if (p.first == me) return
            nearby[id] = p
            // Friend nearby ho to apne aap connect (ek hi taraf se request)
            if (Store.friends(this@MainActivity).containsKey(p.first) && me > p.first && !live.containsKey(p.first))
                client.requestConnection(advert, id, connCb)
            refresh()
        }
        override fun onEndpointLost(id: String) { nearby.remove(id); refresh() }
    }

    private val connCb: ConnectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, i: ConnectionInfo) {
            info[id] = parse(i.endpointName)
            client.acceptConnection(id, payCb)
        }
        override fun onConnectionResult(id: String, r: ConnectionResolution) {
            if (!r.status.isSuccess) return
            val u = info[id]?.first ?: return
            live[u] = id
            if (id in asked) send(id, "FR|$me|$myName")
            refresh()
        }
        override fun onDisconnected(id: String) {
            live.values.remove(id); nearby.clear()
            client.stopDiscovery(); startDisc()
            refresh()
        }
    }

    private val payCb: PayloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, p: Payload) {
            val raw = String(p.asBytes() ?: return)
            val u = info[id]?.first ?: return
            val rest = raw.substringAfter("|", "")
            val fr = Store.friends(this@MainActivity)
            when (raw.substringBefore("|")) {
                "FR" -> {
                    val n = rest.substringAfter("|", u)
                    if (u in fr) send(id, "FA|$me|$myName") else { incoming[u] = n; push("Friend request", "$n (@$u)") }
                    refresh()
                }
                "T" -> if (u in fr && u == current) {
                    typing = true; updateTitle()
                    handler.removeCallbacks(stopTyping); handler.postDelayed(stopTyping, 3000)
                }
                "S" -> if (u in fr) {
                    Store.markSeen(this@MainActivity, u)
                    if (current == u) { chatItems.forEach { if (it.mine) it.seen = true }; chatAdapter.notifyDataSetChanged() }
                }
                "FA" -> if (id in asked) {
                    asked -= id
                    Store.addFriend(this@MainActivity, u, rest.substringAfter("|", u)); refresh()
                }
                "M" -> if (u in fr) {   // sirf friends ke message chalte hain
                    val m = ChatMsg(fr[u] ?: u, rest, false)
                    Store.addMsg(this@MainActivity, u, m)
                    if (current == u) { chatItems += m; chatAdapter.notifyDataSetChanged(); send(id, "S"); typing = false; updateTitle() }
                    else { unread[u] = (unread[u] ?: 0) + 1; push(fr[u] ?: u, rest); refresh() }
                }
            }
        }
        override fun onPayloadTransferUpdate(id: String, u: PayloadTransferUpdate) {}
    }

    private fun refresh() { runOnUiThread {
        val fr = Store.friends(this)
        rows.clear(); keys.clear()
        when (tab) {
            0 -> fr.forEach { (u, n) ->
                rows += "$n  @$u" + (if (live.containsKey(u)) "  ● connected" else "") + (unread[u]?.let { "  ($it new)" } ?: "")
                keys += u
            }
            1 -> nearby.filter { it.value.first !in fr }.forEach { (id, p) -> rows += "${p.second}  @${p.first}  — tap to add"; keys += id }
            else -> incoming.forEach { (u, n) -> rows += "$n  @$u  — wants to be friends"; keys += u }
        }
        if (rows.isEmpty()) {
            rows += listOf("Abhi koi friend nahi. Nearby se add karo.", "Aas-paas koi nahi mila...", "Koi request nahi hai.")[tab]
            keys += ""
        }
        listAdapter.notifyDataSetChanged()
        findViewById<Button>(R.id.tab2).text = "Requests (${incoming.size})"
        findViewById<TextView>(R.id.sub).text = "@$me  ·  nearby: ${nearby.size}"
        updateTitle()
    } }

    private fun onRow(k: String) {
        if (k.isEmpty()) return
        when (tab) {
            0 -> openChat(k)
            1 -> {
                val p = nearby[k] ?: return
                AlertDialog.Builder(this).setTitle("Friend request")
                    .setMessage("${p.second} (@${p.first}) ko request bheju?")
                    .setPositiveButton("Bhejo") { _, _ ->
                        asked += k
                        if (live[p.first] == k) send(k, "FR|$me|$myName") else client.requestConnection(advert, k, connCb)
                    }.setNegativeButton("Cancel", null).show()
            }
            else -> {
                val n = incoming[k] ?: return
                AlertDialog.Builder(this).setTitle("@$k").setMessage("$n friend banna chahta hai")
                    .setPositiveButton("Accept") { _, _ ->
                        Store.addFriend(this, k, n); live[k]?.let { send(it, "FA|$me|$myName") }
                        incoming.remove(k); refresh()
                    }.setNegativeButton("Decline") { _, _ -> incoming.remove(k); refresh() }.show()
            }
        }
    }

    private fun openChat(u: String) {
        current = u; unread.remove(u)
        chatItems.clear(); chatItems += Store.chat(this, u); chatAdapter.notifyDataSetChanged()
        typing = false; updateTitle()
        live[u]?.let { send(it, "S") }   // doosre ko batao ki maine messages dekh liye
        findViewById<View>(R.id.chatPanel).visibility = View.VISIBLE
    }

    private fun updateTitle() {
        val u = current ?: return
        val st = if (typing) "  typing..." else if (live.containsKey(u)) "  ● online" else "  ○ range me nahi"
        findViewById<TextView>(R.id.chatTitle).text = (Store.friends(this)[u] ?: u) + st
    }

    private fun closeChat() {
        current = null
        findViewById<View>(R.id.chatPanel).visibility = View.GONE
        refresh()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (current != null) closeChat() else super.onBackPressed() }

    private fun applyTheme() {
        val c = Store.themes[Store.theme(this)].second
        findViewById<View>(R.id.header).setBackgroundColor(c)
        findViewById<View>(R.id.chatHead).setBackgroundColor(c)
        findViewById<Button>(R.id.send).backgroundTintList = ColorStateList.valueOf(c)
        chatAdapter.notifyDataSetChanged()
    }

    private fun settings() {
        AlertDialog.Builder(this).setItems(arrayOf("Chat theme badlo", "Naam badlo", "Logout")) { _, w ->
            when (w) {
                0 -> AlertDialog.Builder(this).setTitle("Theme")
                    .setItems(Store.themes.map { it.first }.toTypedArray()) { _, i -> Store.setTheme(this, i); applyTheme() }.show()
                1 -> {
                    val e = EditText(this); e.setText(myName)
                    AlertDialog.Builder(this).setTitle("Naya naam").setView(e).setPositiveButton("Save") { _, _ ->
                        val n = e.text.toString().trim().replace("|", " ")
                        if (n.isNotEmpty()) { Store.setName(this, n); Toast.makeText(this, "Naya naam agle login se dikhega", Toast.LENGTH_SHORT).show() }
                    }.show()
                }
                else -> { Store.unlocked = false; finish(); startActivity(Intent(this, LoginActivity::class.java)) }
            }
        }.show()
    }

    private fun push(title: String, text: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, "chat").setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(title).setContentText(text).setAutoCancel(true).setContentIntent(pi).build()
        NotificationManagerCompat.from(this).notify(System.nanoTime().toInt(), n)
    }

    override fun onDestroy() {
        if (::client.isInitialized) { client.stopAllEndpoints(); client.stopAdvertising(); client.stopDiscovery() }
        super.onDestroy()
    }
}
